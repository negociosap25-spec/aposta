/* app.js — Aviator enhanced
 Features:
  - Animated plane that rises with multiplier
  - WebAudio engine for sounds (start, cashout, crash)
  - Fullscreen mode
  - Local coins, levels, XP and leaderboard
  - Persistent via localStorage (export/import)
  - Smooth multiplier and crash simulation with requestAnimationFrame
*/

// ---------- State & Persistence ----------
const STORAGE_KEY = 'betfun_aviator_v2';
let state = {
  users: {}, // userId -> {name, balance, level, xp}
  history: [], // rounds
  currentRound: null
};

function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function loadState(){ const raw = localStorage.getItem(STORAGE_KEY); if (raw) state = JSON.parse(raw); else initDefault(); }

function initDefault(){
  const id = 'user_' + Math.random().toString(36).slice(2,9);
  state.users[id] = { id, name: 'Jogador', balance: 1000, level:1, xp:0 };
  state.currentUserId = id;
  saveState();
}

// ---------- UI refs ----------
const balanceEl = el('balance');
const levelEl = el('level');
const xpEl = el('xp');
const xpNextEl = el('xpNext');
const userNameEl = el('userName');
const multiplierEl = el('multiplier');
const startBtn = el('startBtn');
const cashoutBtn = el('cashoutBtn');
const betInput = el('betInput');
const planeEl = el('plane');
const roundIdEl = el('roundId');
const statusEl = el('status');
const leaderboardEl = el('leaderboard');
const historyEl = el('history');
const exportBtn = el('exportBtn');
const importBtn = el('importBtn');
const fullscreenBtn = el('fullscreenBtn');

function el(id){ return document.getElementById(id); }

// ---------- Audio (WebAudio API) ----------
const AudioCtx = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;
function ensureAudio(){ if (!audioCtx) audioCtx = new AudioCtx(); }

// simple beeps
function beep(freq, dur=0.06, type='sine', gain=0.08){
  ensureAudio();
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.value = gain;
  o.connect(g); g.connect(audioCtx.destination);
  o.start();
  o.stop(audioCtx.currentTime + dur);
}

// sounds
function playStart(){ beep(880,0.06,'sine',0.06); beep(1320,0.04,'sine',0.03); }
function playCashout(){ beep(880,0.08,'triangle',0.08); }
function playCrash(){ beep(160,0.18,'sawtooth',0.16); }

// ---------- Gameplay: multiplier & crash ----------
let rafId = null;
let running = false;
let multiplier = 1.0;
let startTime = 0;
let crashPoint = 0;
let currentBet = null;

// Use a distribution for crash points (so short crashes more common)
// We'll use: crash = max(1.0, exponential with lambda=0.5) capped to 60
function sampleCrash(){
  const u = Math.random();
  const lambda = 0.5;
  const x = -Math.log(1 - u) / lambda;
  const val = Math.max(1, x);
  return Math.min(val, 60);
}

// multiplier growth model — increases smoother than linear
function multiplierAt(t){ // t in seconds
  // exponential-like growth: m(t) = 1 + a * (e^{b t} - 1)
  const a = 0.04, b = 0.8;
  return 1 + a * (Math.exp(b * t) - 1);
}

function formatMult(m){ return m.toFixed(2) + 'x'; }

// ---------- Round control ----------
function startRound(){
  if (running) return;
  const betValue = Number(betInput.value);
  const user = getCurrentUser();
  if (!betValue || betValue <= 0) { alert('Digite um valor de aposta válido'); return; }
  if (betValue > user.balance) { alert('Saldo insuficiente'); return; }

  // debit immediately
  user.balance = Math.round((user.balance - betValue)*100)/100;
  saveState();
  updateUI();

  // init round
  multiplier = 1.0;
  startTime = performance.now();
  crashPoint = sampleCrash();
  running = true;
  currentBet = { id: 'r_' + Math.random().toString(36).slice(2,9), bet: betValue, cashed: false, cashedAt: null, payout: 0, crashed:false, start: new Date().toISOString() };
  state.currentRound = currentBet;
  roundIdEl.innerText = currentBet.id;
  statusEl.innerText = 'Em andamento';
  playStart();
  cashoutBtn.disabled = false;
  startBtn.disabled = true;
  multiplierEl.innerText = formatMult(multiplier);
  planeEl.classList.add('fly');
  document.getElementById('crashFlash').classList.add('hidden');

  // animation loop
  function loop(now){
    const t = (now - startTime)/1000.0;
    multiplier = multiplierAt(t);
    multiplierEl.innerText = formatMult(multiplier);

    // plane vertical position: map multiplier to top percentage
    const topPerc = Math.min(80, 70 - (multiplier - 1) * 6); // simple mapping
    planeEl.style.transform = `translateY(${topPerc}%)`;

    if (multiplier >= crashPoint){
      // crash
      running = false;
      currentBet.crashed = true;
      currentBet.crashAt = multiplier;
      statusEl.innerText = '💥 Avião caiu';
      document.getElementById('crashFlash').classList.remove('hidden');
      playCrash();
      finalizeRound();
      return;
    }
    rafId = requestAnimationFrame(loop);
  }
  rafId = requestAnimationFrame(loop);
  renderHistory(); renderLeaderboard();
}

function cashout(){
  if (!running || !currentBet) return;
  if (currentBet.cashed) return;
  currentBet.cashed = true;
  currentBet.cashedAt = multiplier;
  currentBet.payout = Math.round(currentBet.bet * currentBet.cashedAt * 100)/100;
  // credit to user
  const user = getCurrentUser();
  user.balance = Math.round((user.balance + currentBet.payout)*100)/100;
  // XP gain: proportional to payout
  const xpGain = Math.min(100, Math.round(currentBet.payout / 2));
  user.xp = (user.xp || 0) + xpGain;
  // level up logic
  while (user.xp >= xpForNext(user.level)){
    user.xp -= xpForNext(user.level);
    user.level += 1;
  }
  saveState();
  playCashout();
  finalizeRound(true);
  updateUI();
  renderHistory(); renderLeaderboard();
}

function finalizeRound(cashed=false){
  // stop animation
  if (rafId) cancelAnimationFrame(rafId);
  running = false;
  startBtn.disabled = false;
  cashoutBtn.disabled = true;
  planeEl.classList.remove('fly');
  // if crashed and not cashed, nothing to add (bet was already debited)
  if (!currentBet) return;
  if (!cashed && currentBet.crashed === false && !currentBet.cashed){
    // edge case (if round stopped some other way)
  }
  // push to history
  state.history.unshift(Object.assign({}, currentBet, { multiplierAtCrash: currentBet.crashAt || null }));
  // limit history
  if (state.history.length > 200) state.history.pop();
  // reset currentRound
  state.currentRound = null;
  currentBet = null;
  saveState();
  updateUI();
  renderHistory();
}

// ---------- Helpers ----------
function getCurrentUser(){ return state.users[state.currentUserId]; }
function xpForNext(level){ return Math.round(100 * Math.pow(1.15, level-1)); }

// ---------- UI Rendering ----------
function updateUI(){
  const u = getCurrentUser();
  balanceEl.innerText = u.balance.toFixed(2);
  levelEl.innerText = u.level;
  xpEl.innerText = u.xp;
  xpNextEl.innerText = xpForNext(u.level);
  userNameEl.innerText = u.name;
  if (!running){
    planeEl.style.transform = 'translateY(70%)';
  }
}

function renderLeaderboard(){
  const arr = Object.values(state.users).sort((a,b)=> b.balance - a.balance);
  leaderboardEl.innerHTML = arr.map(u => `<div class="row"><b>${escapeHtml(u.name)}</b> — R$ ${u.balance.toFixed(2)} <small class="small">Lvl ${u.level}</small></div>`).join('');
}

function renderHistory(){
  historyEl.innerHTML = state.history.slice(0,30).map(h=>{
    const time = new Date(h.start).toLocaleString();
    if (h.cashed){
      return `<div>✅ ${time} — Apostou R$${h.bet} → Sacou em ${h.cashedAt.toFixed(2)}x = R$${h.payout.toFixed(2)}</div>`;
    } else if (h.crashed){
      return `<div>💥 ${time} — Apostou R$${h.bet} — Avião caiu em ${h.crashAt.toFixed(2)}x</div>`;
    } else {
      return `<div>— ${time} — Round incompleto</div>`;
    }
  }).join('');
}

// ---------- Export / Import ----------
exportBtn.addEventListener('click', ()=>{
  const blob = new Blob([JSON.stringify(state, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'betfun_aviator_backup.json'; a.click();
  URL.revokeObjectURL(url);
});

importBtn.addEventListener('click', ()=>{
  const f = document.createElement('input'); f.type='file'; f.accept='application/json';
  f.onchange = async ()=> {
    const file = f.files[0]; if (!file) return;
    const txt = await file.text();
    try{
      const data = JSON.parse(txt);
      if (data && data.users){
        state = data;
        saveState();
        updateUI(); renderHistory(); renderLeaderboard();
        alert('Importado com sucesso.');
      } else alert('Arquivo inválido');
    } catch(e){ alert('Erro no arquivo: ' + e.message) }
  };
  f.click();
});

// ---------- Fullscreen ----------
fullscreenBtn.addEventListener('click', ()=>{
  const el = document.documentElement;
  if (!document.fullscreenElement){
    el.requestFullscreen().catch(()=>{});
  } else {
    document.exitFullscreen().catch(()=>{});
  }
});

// ---------- Utilities ----------
function escapeHtml(s){ return String(s).replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[m])); }

// ---------- Bind UI ----------
startBtn.addEventListener('click', startRound);
cashoutBtn.addEventListener('click', cashout);

// ---------- Init ----------
loadState();
updateUI();
renderLeaderboard();
renderHistory();

// If there is an in-progress round in saved state, clear it (for simplicity)
if (state.currentRound){
  state.currentRound = null;
  saveState();
}
